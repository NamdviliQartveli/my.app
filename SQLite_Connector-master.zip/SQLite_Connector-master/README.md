# SQLite_Connector
//SQLite Connector Dataaccess Class and sqlite.net dll

1. Use this DataAccess.cs file to connect sqlite, SQL, MYSQL or oracle Database server 
2. Insert Database information 
3. Add SQLITE.NET.DLL as Reference 
4. Run
